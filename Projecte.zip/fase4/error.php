
<html>
	<title>P&agrave;gina d'indentificaci&oacute; de l'usuari del qual es volen mostrar dades</title>
	<div>
    <form action="login.php"	 method=post>
        <p>Error, l'usuari o la contrasenya no son corrrectes torna a la pàgina login per tornar-ho a provar</p>
        <input type="submit">
    </form>
    </div>
</html>
